# aria-engine (private)

ARIA's local execution engine — the component that runs on a device the
user controls, observes the Solana chain, evaluates opportunities, and
(in later phases, not REAL-1) executes trades under a constrained, revocable
signing authority.

**This is a separate repository from `AIWMCX/aria-telegram-BOT-APP`
on purpose.** That repo is the public control plane (Telegram identity,
licensing/entitlement, account state, Railway-hosted API). This repo is
proprietary execution logic and must never be merged into or copied from
the public repo, and the public repo's source must never be copied in here
either — see `docs/ARIA_FUNDS_ARCHITECTURE_V1.md` in the control-plane repo
for the full architecture this engine is one component of.

## REAL-1 scope: PAPER-ONLY

This phase never touches real funds. Explicitly forbidden anywhere in this
repository until a later, separately-approved phase:

- loading a Solana wallet private key or seed phrase
- constructing, signing, or broadcasting a Solana transaction
- calling `sendTransaction` / `sendRawTransaction` / `simulateTransaction`
  or any RPC method that submits a transaction to the network
- holding or requesting custody of any asset
- Jupiter swap execution, Jito bundle submission

`src/contracts.test.ts` and `src/paper/paper-hard-stop.test.ts` include
automated scans that fail the build if any of those identifiers appear in
production `src/` — a structural guardrail, not just a policy statement,
so a future task can't accidentally cross this line without a red test
forcing a conscious decision first. There is no `@solana/web3.js`
dependency in this repo — no `Keypair`/`Transaction` symbol is even
importable, let alone reachable.

A local Ed25519 **DeviceAuthIdentity** key (`src/device-auth.ts`,
`src/local-keystore.ts`) authenticates this engine's requests to the
control plane. It is explicitly NOT a Solana wallet key — different
module, different purpose, never combined with any future signing
concept.

## Status — REAL-1 Tasks 1–7 (Tasks 8+ not started)

| Task | What it added |
|---|---|
| 1 | Domain contracts (`src/contracts.ts`) — types, control-state transitions, no I/O |
| 2 | `ARIAE1` entitlement verification (`src/entitlement.ts`) — offline Ed25519, fail-closed, 7-day paper-beta scope |
| 3 | (control-plane repo) Postgres storage for `engine_entitlements`/`engine_clients` |
| 4 | Device pairing + authenticated sync (`src/device-auth.ts`, `src/local-keystore.ts`, `src/pairing-state.ts`, `src/pairing-client.ts`) — real Ed25519-signed requests to the control plane, replay-resistant via a monotonic sequence |
| 5 | Read-only Solana RPC (`src/solana-rpc.ts`, `src/solana-config.ts`) — raw JSON-RPC over `fetch`, no `@solana/web3.js` |
| 6 | Deterministic paper-trading engine (`src/paper/`) — positions, fills, TP/SL/max-age exits, HARD STOP |
| 7 | The `aria` CLI and local runtime (`src/cli.ts`, `src/runtime/`) — doctor, pairing, the paper control loop, local persistence, crash recovery |

Pairing is real and implemented — the line above calling it "not yet
implemented" was stale as of Task 4 landing; this file is that correction.

## Toolchain

Same conventions as `aria-telegram-BOT-APP`: plain `npm`, `tsx` for running
TypeScript directly (no build step), no test framework — self-contained
scripts under `src/**/*.test.ts` using `console.log`/exit-code assertions.

```bash
npm install
npm run typecheck
npm test
```

## Running ARIA today

There is **no packaged installer yet** — that's real, separate work not
done as part of Task 7 (cross-platform `.exe`/`.dmg` packaging needs a
Node-bundling toolchain that hasn't been set up). Today, ARIA runs via:

```bash
npx tsx src/cli.ts <command>
```

or the equivalent npm scripts:

```bash
npm run doctor     # aria doctor
npm start -- status  # any command via `npm start -- <command>`
```

### Command surface

```
aria version
aria doctor
aria pair <CODE>
aria unpair
aria status
aria paper start|pause|stop
aria positions
aria performance
aria logs [--tail]
aria config show
aria config set <key> <value>
```

Deliberately absent, and structurally impossible to add without violating
the HARD STOP: `aria buy`, `aria sell`, `aria live`, `aria wallet import`,
`aria private-key`.

### Device pairing

The engine authenticates itself to the public control plane via a
short-lived, single-use pairing code issued through Telegram (the control
plane's `POST /api/engine/pairing-code`, Telegram-authenticated). `aria
pair <CODE>` generates a local Ed25519 `DeviceAuthIdentity` (if one
doesn't already exist) and exchanges the code for a registered device via
`POST /api/engine/pair`. The engine never independently trusts a Telegram
user ID supplied by itself — pairing is only ever established by the
control plane's own verified `initData` flow.

### Local data layout

```
~/.aria/
  config.json               human-editable settings (RPC URL, paper limits)
  state/
    device-identity.json    DeviceAuthIdentity — Ed25519 keypair, 0600 permissions, NOT a wallet key
    pairing-state.json      {clientId, lastSequence}
    paper-snapshot.json     full paper-engine state, for restart recovery
  logs/
    aria.log
  run/
    aria.lock                single-instance lock (PID-based, stale locks are auto-reclaimed)
```

### Current honest limitations (not yet built)

- **No real market-price feed adapter.** `aria paper start` uses
  `SyntheticMarketSource` (`src/runtime/market-source.ts`) — clearly
  labeled synthetic/test data (`CandidateSource: "test"`), never presented
  as a real market observation. A real Pump.fun/Raydium/Jupiter-price
  adapter is separate, later work.
- **No cross-platform installer/packaging.** Testers currently need
  Node.js + this repo checked out; a real `ARIA-*.zip` / `.exe` / `.dmg`
  release artifact is not built yet.
- **`aria paper start` runs in the foreground.** Pause/stop from another
  terminal works via a local control file the loop polls each tick, but
  there's no background-daemon mode yet.
- **No `aria doctor` clock-skew or DNS-specific checks yet** — network
  reachability and RPC cluster/freshness checks exist; a few of the
  originally-requested finer-grained diagnostics don't yet.

## Related documents

- `docs/ARIA_FUNDS_ARCHITECTURE_V1.md` (control-plane repo) — full funds
  architecture, custody classification (`DELEGATED_VENDOR`), ledger design
- `docs/ARIA_MASTER_PROMPTS.md` (control-plane repo) — reusable build/
  audit/coordinate prompts encoding this project's evidence discipline
